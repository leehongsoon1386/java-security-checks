# INTRODUCTION

This Docker Compose file defines two services - one for `Prometheus` and one for `Alertmanager`. It mounts configuration files (`prometheus.yml` and `alertmanager.yml`) into the containers.

# RUN

```
docker-compose up -d
```

## Access the Prometheus console:
- Open a web browser and go to http://localhost:9090/. You should see the Prometheus web UI.

## Access Alertmanager UI
- Open a web browser and go to http://localhost:9093/. You should see the Alertmanager web UI.

## Access Grafana UI
- Open a web browser and go to http://localhost:3000/. You should see the Alertmanager web UI.

# CLEANUP

```
docker-compose down
```
